# 🏥 Sistem Manajemen Reservasi Antrian Rumah Sakit

Sistem Manajemen Reservasi Antrian Rumah Sakit adalah aplikasi berbasis web dinamis yang dibangun menggunakan **PHP Native** dan **MySQL**. Sistem ini dirancang untuk memudahkan petugas administrasi rumah sakit dalam mengelola antrean pasien secara *real-time*, dengan menerapkan konsep *Object Oriented Programming* (OOP) tingkat lanjut untuk kalkulasi biaya medis.

## ✨ Fitur Utama
- **Kelola Antrean Pasien (CRUD):** Tambah pasien baru, Edit status/poli pasien, Lihat daftar tunggu, dan Hapus (Tandai Selesai) antrean.
- **Sistem Kalkulasi Biaya Cerdas (OOP):** Menggunakan polimorfisme untuk membedakan secara otomatis tagihan antara pasien **Umum** (bayar penuh) dan pasien **BPJS** (gratis/subsidi).
- **User Interface Responsif & Interaktif:** Dibangun menggunakan *framework* **Bootstrap 5**, dilengkapi fitur *Modal* (pop-up) agar manipulasi antrean dapat dilakukan tanpa perpindahan halaman yang mengganggu.

## 🛠️ Teknologi yang Digunakan
- **Backend:** PHP Native (termasuk OOP, PDO/MySQLi, Namespace)
- **Database:** MySQL
- **Frontend:** HTML5, CSS3
- **Library Tambahan:** Bootstrap 5 (via CDN)

## 📂 Struktur Folder Berbasis Clean Architecture
Proyek ini memisahkan logika *backend*, akses basis data, dan antarmuka *frontend* ke dalam *namespace* dan direktori yang berbeda:
```text
Sistem_Antrian_RS/
├── html/
│   └── public/
│       └── dashboard.php           # Antarmuka utama (UI) & Output Tabel
├── php/
│   ├── config/
│   │   └── koneksi.php             # Konfigurasi parameter MySQL
│   ├── controller/
│   │   ├── proses_tambah.php       # Prosedur input pasien baru
│   │   ├── proses_edit.php         # Prosedur pembaruan data pasien
│   │   └── proses_hapus.php        # Prosedur penyelesaian antrean
│   └── interfaceandmodel/
│       ├── SistemAntrian.php       # Class OOP utama (PasienUmum, PasienBPJS)
│       └── SistemHelper.php        # Fungsi bantuan format Rupiah
└── README.md                       # Dokumentasi panduan sistem