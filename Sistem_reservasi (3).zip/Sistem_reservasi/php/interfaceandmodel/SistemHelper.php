<?php
namespace SistemHelper;

/* Fungsi bantuan untuk mengubah angka menjadi format mata uang Rupiah */
function formatRupiah($angka) {
    return "Rp " . number_format($angka, 0, ",", ".");
}
?>