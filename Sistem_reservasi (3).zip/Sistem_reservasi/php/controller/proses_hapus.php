<?php
include_once __DIR__ . "/../config/koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($conn, "DELETE FROM antrian WHERE id_antrian='$id'");

if($query) {
    header("Location: ../../html/public/dashboard.php");
}
?>