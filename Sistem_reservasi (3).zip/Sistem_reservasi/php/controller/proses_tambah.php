<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once __DIR__ . "/../config/koneksi.php";
require_once __DIR__ . "/../interfaceandmodel/SistemAntrian.php";

use AntrianRS\PasienUmum;
use AntrianRS\PasienBPJS;

/* Menangkap data dari form */
$nama_pasien  = $_POST['nama_pasien'];
$poli_tujuan  = $_POST['poli_tujuan'];
$jenis_pasien = $_POST['jenis_pasien'];

/* Logika Control Structure (If-Else) & OOP */
if ($jenis_pasien == "BPJS") {
    $pasien = new PasienBPJS();
} else {
    $pasien = new PasienUmum();
}

// Mengambil hasil perhitungan method OOP
$biaya = $pasien->hitungBiaya();

/* Query Insert */
$query = mysqli_query($conn, "INSERT INTO antrian (nama_pasien, poli_tujuan, jenis_pasien, biaya) VALUES ('$nama_pasien', '$poli_tujuan', '$jenis_pasien', '$biaya')");

/* Error Handling Query */
if($query) {
    echo "<script>
            alert('Sukses! Pasien masuk antrian.'); 
            window.location.href='../../html/public/dashboard.php';
          </script>";
} else {
    echo "<h1>GAGAL MENAMBAHKAN PASIEN!</h1>";
    echo "Pesan Error: " . mysqli_error($conn);
}
?>